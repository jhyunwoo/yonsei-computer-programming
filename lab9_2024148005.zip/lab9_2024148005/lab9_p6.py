# (C) Wiley (the textbook publisher).
#
# The programs in this folder are provided for your personal studies only.
# You are NOT allowed to publish this program in any form.
# - Do not put it on a public source repository like github.
# - Do not put it on a web-site or similar.

# Horse Racing Program

import turtle
import random
import time

def getHorseImages(num_horses):
    """
    Get horse images from img folder
    :param num_horses: int value
    :return: path of images
    """
    # init empty list
    images = []

    # get all horse images
    for k in range(0, num_horses):
        images = images + ['img/horse_' + str(k+1) + '_image.gif']

    return images

def getBannerImages(num_horses):
    """
    Get banner images from img folder
    :param num_horses: int value
    :return: banner images path list
    """
    # init empty list
    all_images = []

    # get "They're Off" banner image
    images = ['img/theyre_off_banner.gif']
    all_images.append(images)

    # get early lead banner images
    images = []
    for k in range(0, num_horses):
        images = images + ['img/lead_at_start_' + str(k+1) + '.gif']
    all_images.append(images)

    # get mid-way lead banner images
    images = []
    for k in range(0, num_horses):
        images = images + ['img/looking_good_' + str(k+1) + '.gif']
    all_images.append(images)

    # get "We Have a Winner" banner image
    images = ['img/winner_banner.gif']
    all_images.append(images)

    return all_images

def registerHorseImages(images):
    """
    Register horse images on turtle graphics
    :param images: images path list
    :return: Nothing
    """
    for k in range(0, len(images)):
        turtle.register_shape(images[k])

def registerBannerImages(images):
    """
    Register banner images on turtle graphics
    :param images: images path list
    :return: Nothing
    """
    for k in range(0, len(images)):
        for j in range(0, len(images[k])):
            turtle.register_shape(images[k][j])

def newHorse(image_file):
    """
    Create new horse image on turtle graphics
    :param image_file: image file path
    :return: horse turtle graphics
    """
    horse = turtle.Turtle()
    horse.hideturtle()
    horse.shape(image_file)

    return horse

def generateHorses(images, num_horses):
    """
    Generate horse images on turtle graphics
    :param images: image path list
    :param num_horses: int value
    :return: horses turtle graphics
    """
    horses = []
    for k in range(0, num_horses):
        horse = newHorse(images[k])
        horses.append(horse)

    return horses

def placeHorses(horses, loc, separation):
    """
    Place horse images on turtle graphics
    :param horses: horses turtle graphics
    :param loc: coordinates of horse location
    :param separation: int value
    :return: Nothing
    """
    for k in range(0, len(horses)):
        horses[k].hideturtle()
        horses[k].penup()
        horses[k].setposition(loc[0], loc[1] + k * separation)
        horses[k].setheading(180)
        horses[k].showturtle()
        horses[k].pendown()

def findLeadHorse(horses):
    """
    Find lead horse images on turtle graphics
    :param horses: horses turtle graphics
    :return: int value of lead horse number
    """
    # init
    lead_horse = 0

    for k in range(1, len(horses)):
        if horses[k].position()[0] < \
                horses[lead_horse].position()[0]:
            lead_horse = k
    return lead_horse

def displayBanner(banner, position):
    """
    Display banner on turtle graphics
    :param banner: banner image path
    :param position: x and y coordinates of banner location
    :return: Nothing
    """
    the_turtle = turtle.getturtle()
    turtle.setposition(position[0], position[1])
    turtle.shape(banner)
    turtle.stamp()

def startHorses(horses, banners, finish_line, forward_incr):
    """
    Start horse images on turtle graphics
    :param horses: horses turtle graphics
    :param banners: banner images path list
    :param finish_line: int value
    :param forward_incr: int value
    :return: winner horse index
    """
    # init
    have_winner = False
    early_leading_horse_displayed = False
    midrace_leading_horse_displayed = False

    # display "there're off" banner
    displayBanner(banner_images[0][0], (70, -300))

    k = 0
    while not have_winner:
        horse = horses[k]
        horse.forward(random.randint(1,3) * forward_incr)

        # display mid-race lead banner
        lead_horse = findLeadHorse(horses)
        if horses[lead_horse].position()[0] < -125 and \
                not midrace_leading_horse_displayed:

            displayBanner(banners[2][lead_horse], (40, -300))
            midrace_leading_horse_displayed = True

        # display early lead banner
        elif horses[lead_horse].position()[0] < 125 and \
                not early_leading_horse_displayed:
            displayBanner(banners[1][lead_horse], (10, -300))
            early_leading_horse_displayed = True

        # check for horse over finish line
        if horse.position()[0] < finish_line:
            have_winner = True
        else:
            k = (k+1) % len(horses)
    return k

def displayWinner(winning_horse, winner_banner):
    """
    Display winner horse banner on turtle graphics
    :param winning_horse: int value (horse index)
    :param winner_banner: banner image path
    :return: Nothing
    """
    # display "We Have a Winner" banner
    displayBanner(winner_banner, (20, -300))

    # blink winning horse
    show = False
    counter = 10
    while counter != 0:
        if show:
            winning_horse.showturtle()
            show = False
        else:
            winning_horse.hideturtle()
            show = True

        counter = counter - 1
        time.sleep(.4)


# ---- main

# init number of horses
num_horses = 10

# set window size
turtle.setup(750,800)

# get turtle window
window = turtle.Screen()

# set window title bar
window.title('Horse Race Simulation Program')

winners = []
while True:
    # hide default turtle and keep from drawing
    turtle.hideturtle()
    turtle.penup()

    # init screen layout parameters
    start_loc = (240, -200)
    finish_line = -240
    track_separation = 60
    forward_incr = 6

    # register images
    horse_images = getHorseImages(num_horses)
    banner_images = getBannerImages(num_horses)
    registerHorseImages(horse_images)
    registerBannerImages(banner_images)

    # generate and init horses
    horses = generateHorses(horse_images, num_horses)

    # place horses at starting line
    placeHorses(horses, start_loc, track_separation)

    # start horses
    winner = startHorses(horses, banner_images, finish_line,
                         forward_incr)

    # light up for winning horse
    displayWinner(horses[winner], banner_images[3][0])
    # Reset all graphics
    window.clear()

    # Store winner horse info
    winners.append(winner)

    # Ask user to continue simulation
    continue_simulation = input("Press 'q' to quit: ")
    turtle.penup()
    # Print result when user input 'q'
    if continue_simulation == 'q':
        for i in range(0, num_horses):
            print(f"Horse {i+1} won {winners.count(i)} times")
        break
